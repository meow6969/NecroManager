﻿-- chunkname: @/var/folders/r9/xbxmw8n51957gv9ggzrytvf80000gp/T/com.ironhidegames.frontiers.windows.steam.ep3S4swo/version.lua

version = {}
version.identity = "kingdom_rush_frontiers"
version.title = "Kingdom Rush Frontiers"
version.string = "kr2-desktop-5.4.07"
version.string_short = "5.4.07"
version.bundle_id = "com.ironhidegames.frontiers.windows.steam"
version.vc = "kr2-desktop-5.4.07"
version.build = "DEBUG"
version.bundle_keywords = "-frontiers-windows-steam"
