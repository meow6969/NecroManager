﻿-- chunkname: @./version.lua

version = {}
version.identity = "kingdom_rush"
version.title = "Kingdom Rush"
version.string = "kr1-desktop-5.6.09"
version.string_short = "5.6.09"
version.bundle_id = "com.ironhidegames.kingdomrush.windows.steam"
version.vc = "kr1-desktop-5.6.09"
version.build = "DEBUG"
version.bundle_keywords = "-windows-steam"
