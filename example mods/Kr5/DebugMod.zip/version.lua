﻿-- chunkname: @./version.lua

version = {}
version.identity = "kingdom_rush_alliance"
version.title = "Kingdom Rush Alliance"
version.string = "kr5-desktop-1.00.20"
version.string_short = "1.00.20"
version.bundle_id = "com.ironhidegames.kingdomrush.alliance.windows.steam"
version.vc = "kr5-desktop-1.00.20"
version.build = "DEBUG"
version.bundle_keywords = "-windows-steam"
