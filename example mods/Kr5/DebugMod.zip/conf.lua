﻿-- chunkname: @./conf.lua

function love.conf(t)
	t.modules.physics = false
	t.console = true
end
