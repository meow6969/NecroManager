﻿-- chunkname: @./version.lua

version = {}
version.identity = "kingdom_rush_origins"
version.title = "Kingdom Rush Origins"
version.bundle_id = "com.ironhidegames.origins.windows.steam"
version.string = "kr3-desktop-4.2.10"
version.string_short = "4.2.10"
version.vc = "kr3-desktop-4.2.10"
version.build = "DEBUG"
version.bundle_keywords = "-origins-windows-steam"
